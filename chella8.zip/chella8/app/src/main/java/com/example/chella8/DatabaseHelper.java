package com.example.chella8;

import android.database.Cursor;

public class DatabaseHelper {
    public DatabaseHelper(MainActivity mainActivity) {
    }

    public boolean addStudent(String name, String regno, String department) {
    }

    public Cursor getStudents() {
        return null;
    }

    public boolean updateStudent(String name, String regno, String department) {
    }

    public boolean deleteStudent(String regno) {
    }

    public void close() {
    }
}
